/**
*PROGRAMMED BY: Denmark Warrene Alulod
*SECTION: G-12-IC2AD
*DATE SUBMITTED: May, 11, 2022
*SUBJECT: CP1222
ICT-INSTRUCTOR: SIR SETH
*FINAL PRACTICAL TEST/PROJECT IN CP1222 CREATING STUDENT INFORMATION SYSTEM
**/
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class UpdateRecord {
    static Scanner s = new Scanner(System.in);
    static String id,surname,name,course,school,address,email;
    static ArrayList<String> Schoollist = new ArrayList<>();
    static ArrayList<String> Courselist = new ArrayList<>();
    static ArrayList<String> Addresslist = new ArrayList<>();
    static ArrayList<String> Emaillist = new ArrayList<>();
    static ArrayList<String> Namelist = new ArrayList<>();
    static ArrayList<String> LastNamelist = new ArrayList<>();
    static char in,key;
    static int ll=0,nl=0,sl=0,cl=0,al=0,el;
    static DbConnection dB = new DbConnection();

    public static void UpdateStudentCredentials(){
        ll = ll+1;
        nl = nl+1;
        cl = cl+1;
        al = al+1;
        el = el+1;
        sl = sl+1;
        do {
            try {
            dB.DbConnect();
            System.out.println("****************************************************************");
            System.out.println("|                    UPDATE RECORDS SECTION                    |");
            System.out.println("****************************************************************");;
            System.out.println("|                   [CP1222 - JAVA ACTIVITY]                   |");
            System.out.println("|                                                              |");
            System.out.println("|                    1. TO UPDATE FIRSTNAME                    |");
            System.out.println("|                    2. TO UPDATE LASTNAME                     |");
            System.out.println("|                    3. TO UPDATE COURSE                       |");
            System.out.println("|                    4. TO UPDATE SCHOOL                       |");
            System.out.println("|                    5. TO UPDATE ADDRESS                      |");
            System.out.println("|                    6. TO UPDATE EMAIL                        |");
            System.out.println("|                    7. QUIT UPDATING RECORDS                  |");
            System.out.println("****************************************************************");
            System.out.print("SELECT ITEM :> ");
            key = s.next().charAt(0);
                while(!formKeyOrg(getKey2())){
                    System.out.println("Invalid selected item......");
                    System.out.print("SELECT ITEM :> ");
                    key = s.next().charAt(0);
                }
            switch (key) {
                case '1':
                System.out.println("You selected option 1: TO UPDATE FIRSTNAME");
                firstNameForm();
                break;
                case '2':
                System.out.println("You selected option 2: TO UPDATE LASTNAME");
                lastNameForm();
                break;
                case '3':
                System.out.println("You selected option 3: TO UPDATE COURSE");
                courseForm();
                    break;
                case '4':
                System.out.println("You selected option 4: TO UPDATE SCHOOL");
                schoolForm();
                    break;
                case '5':
                System.out.println("You selected option 5: TO UPDATE ADDRESS");
                addressForm();
                    break;
                case '6':
                System.out.println("You selected option 6: TO UPDATE EMAIL");
                emailForm();
                    break;
                case '7':
                System.out.println("You selected option 7: QUIT UPDATING RECORDS");
                System.out.println("End of updating section.....");
                resultForm(); 
                MainProgram.Form();
                    break;
                }
            
            } catch (Exception e) {
                System.err.println("Something went wrong!!!");
            }
            System.out.println("****************************************************************");
            System.out.println("|                     UPDATE ANOTHER DATA                      |");
            System.out.println("|                      PRESS [N] FOR YES                       |");
            System.out.println("|                      PRESS [Y] FOR NO                        |");
            System.out.println("****************************************************************");
            System.out.print("ENTER YOUR CHOICE: ");
            in = s.next().charAt(0);
            while(!formKey(getKey())){
                    System.out.println("Invalid input!!!"); 
                    System.out.println("****************************************************************");
                    System.out.println("|                     UPDATE ANOTHER DATA                      |");
                    System.out.println("|                      PRESS [N] FOR YES                       |");
                    System.out.println("|                      PRESS [Y] FOR NO                        |");
                    System.out.println("****************************************************************");
                    System.out.print("ENTER YOUR CHOICE: ");
                    in = s.next().charAt(0);
            }
        } while (in == 'y'|| in == 'Y');
        if(in == 'n'|| in == 'N'){
                System.out.println("End of updating section.....");
                resultForm();
                MainProgram.Form();
        }
        resultForm();
    }

    static void resultForm(){
        System.out.println("=====================================");
        System.out.println("|        RECENT AFFECTED ROWS       |");
        System.out.println("|                                   |");
        String [] names = Namelist.toArray(new String[0]);
        String [] surnames = LastNamelist.toArray(new String[0]);
        String [] courses = Courselist.toArray(new String[0]);
        String [] schools = Schoollist.toArray(new String[0]);
        String [] addresses = Addresslist.toArray(new String[0]);
        String [] emails = Emaillist.toArray(new String[0]);
        System.out.println("|              ENTRIES              |");
        System.out.println("=====================================\n");
        for(int i=0;i<1;i++){
            System.out.printf("%-4s%-11s%-25s\n","NO","ID","NAME");
            for(String n: names){
                System.out.printf("%-40s\n",n);
            }
        }
        System.out.println(" ");
        for(int i = 0;i<1;i++){
            System.out.printf("%-4s%-11s%-25s\n","NO","ID","SURNAME");
            for(String s: surnames){
                System.out.printf("%-40s\n",s);
            }
        }
        System.out.println(" ");
        for(int i = 0; i<1;i++){
            System.out.printf("%-4s%-11s%-25s\n","NO","ID","COURSE");
            for(String c: courses){
                System.out.printf("%-40s\n",c);
            }
        }
        System.out.println(" ");
        for(int i = 0; i<1;i++){
            System.out.printf("%-4s%-11s%-25s\n","NO","ID","SCHOOL");
            for(String sc: schools){
                System.out.printf("%-40s\n",sc);
            }
        }
        System.out.println(" ");
        for(int i = 0; i<1;i++){
            System.out.printf("%-4s%-11s%-25s\n","NO","ID","ADDRESS");
            for(String a: addresses){
                System.out.printf("%-40s\n",a);
            }
        }
        System.out.println(" ");
        for(int i = 0; i<1;i++){
            System.out.printf("%-4s%-11s%-25s\n","NO","ID","EMAIL");
            for(String e: emails){
                System.out.printf("%-40s\n",e);
            }
        }
        System.out.println("\n=====================================\n");
        dB.DbCloseConnection();
        Emaillist.clear();
        Namelist.clear();
        LastNamelist.clear();
        Courselist.clear();
        Addresslist.clear();
        Schoollist.clear();
        ll = 0;
        nl = 0;
        cl = 0;
        al = 0;
        el = 0;
        sl = 0;
    }

    // UPDATE SECTION
    private static void UpdateEmail(String address2) {
        String queString = "UPDATE students set EMAIL = ? WHERE STD_ID ="+"'"+getID()+"'";
        if(checkEmail(getID(),getEmail())){
            System.out.println("["+getID()+"] "+"Cannot change email to "+getEmail());
            el--;
        } else if(address2.isBlank()||address2.isEmpty()){
            System.out.println("----------------------------------------------------------------");
            System.out.println("|                    EMAIL CANNOT BE EMPTY                     |");
  System.out.println("----------------------------------------------------------------");
        } else {
            try {
                dB.DbConnect();
                PreparedStatement ps = DbConnection.con.prepareStatement(queString);
                ps.setString(1, address2);
                int rawUp = ps.executeUpdate();
                if(rawUp>0){
                    System.out.println("********************************************************************************************************************************************");
                    System.out.println("|                                           ["+getID()+"],        EMAIL IS UPDATED SUCCESSFULLY                                                 |");
                    System.out.println("********************************************************************************************************************************************");
                    SelectRecord.showData();
                    dB.DbCloseConnection();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            Emaillist.add("["+el+"] "+getID()+"     "+getEmail());
            el++;
        }
    }

    private static void UpdateAddress(String address2) {
        String queString = "UPDATE students set ADDRESS = ? WHERE STD_ID ="+"'"+getID()+"'";
        if(checkAddress(getID(),getAddress())){
            System.out.println("["+getID()+"] "+"Cannot change address to "+getAddress());
            al--;
        } else if(address2.isBlank()||address2.isEmpty()){
            System.out.println("----------------------------------------------------------------");
            System.out.println("|                   ADDRESS CANNOT BE EMPTY                    |");
            System.out.println("----------------------------------------------------------------");
        } else {
            try {
                dB.DbConnect();
                PreparedStatement ps = DbConnection.con.prepareStatement(queString);
                ps.setString(1, address2);
                int rawUp = ps.executeUpdate();
                if(rawUp>0){
                    System.out.println("********************************************************************************************************************************************");
                    System.out.println("|                                           ["+getID()+"],        ADDRESS IS UPDATED SUCCESSFULLY                                               |");
                    System.out.println("********************************************************************************************************************************************");
                    SelectRecord.showData();
                    dB.DbCloseConnection();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            Addresslist.add("["+al+"] "+getID()+"     "+getAddress());
            al++;
        }
    }

    private static void UpdateCourse(String Course2) {
        String queString = "UPDATE students set COURSE = ? WHERE STD_ID ="+"'"+getID()+"'";
        if(checkCourse(getID(),getCourse())){
            System.out.println("["+getID()+"] "+"Cannot change school to "+getCourse());
            cl--;
        }else if(Course2.isBlank()||Course2.isEmpty()){
            System.out.println("----------------------------------------------------------------");
            System.out.println("|                   COURSE CANNOT BE EMPTY                     |");
            System.out.println("----------------------------------------------------------------");
        } else {
            try {
                dB.DbConnect();
                PreparedStatement ps = DbConnection.con.prepareStatement(queString);
                ps.setString(1, Course2);
                int rawUp = ps.executeUpdate();
                if(rawUp>0){
                    System.out.println("********************************************************************************************************************************************");
                    System.out.println("|                                           ["+getID()+"],        COURSE IS UPDATED SUCCESSFULLY                                                |");
                    System.out.println("********************************************************************************************************************************************");
                    SelectRecord.showData();
                    dB.DbCloseConnection();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
            Courselist.add("["+cl+"] "+getID()+"     "+getCourse());
            cl++;
        }
    }
    // FIRSTNAME UPDATE
    private static void UpdateSchool(String School){
        String queString = "UPDATE students set SCHOOL = ? WHERE STD_ID ="+"'"+getID()+"'";
        if(checkSchool(getID(),getSchool())){
            System.out.println("["+getID()+"] "+"Cannot change school to "+getSchool());
            sl--;
        }else if(School.isBlank()||School.isEmpty()){
            System.out.println("----------------------------------------------------------------");
            System.out.println("|                   SCHOOL CANNOT BE EMPTY                     |");
            System.out.println("----------------------------------------------------------------");
        } else {
            try {
                dB.DbConnect();
                PreparedStatement ps = DbConnection.con.prepareStatement(queString);
                ps.setString(1, School);
                int rawUp = ps.executeUpdate();
                if(rawUp>0){
                    System.out.println("********************************************************************************************************************************************");
                    System.out.println("|                                           ["+getID()+"],        SCHOOL IS UPDATED SUCCESSFULLY                                                |");
                    System.out.println("********************************************************************************************************************************************");
                    SelectRecord.showData();
                    dB.DbCloseConnection();
                }
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            Schoollist.add("["+sl+"] "+getID()+"     "+getSchool());
            sl++;
        }
    }

    // FIRSTNAME UPDATE
    private static void UpdateFirstName(String name){
        String queString = "UPDATE students set FNAME = ? WHERE STD_ID ="+"'"+getID()+"'";
        if(checkFirstName(getID(),getName())){
            System.out.println("["+getID()+"] "+"Cannot change firsname to "+getName());
            nl--;
        } else if(name.isBlank()||name.isEmpty()){
            System.out.println("----------------------------------------------------------------");
            System.out.println("|                   FIRSTNAME CANNOT BE EMPTY                  |");
            System.out.println("----------------------------------------------------------------");
        } else {
            try {
                dB.DbConnect();
                PreparedStatement ps = DbConnection.con.prepareStatement(queString);
                ps.setString(1, name);
                int rawUp = ps.executeUpdate();
                if(rawUp>0){
                    System.out.println("********************************************************************************************************************************************");
                    System.out.println("|                                           ["+getID()+"],        FIRSTNAME IS UPDATED SUCCESSFULLY                                             |");
                    System.out.println("********************************************************************************************************************************************");
                    SelectRecord.showData();
                    dB.DbCloseConnection();
                }
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            Namelist.add("["+nl+"] "+getID()+"     "+getName());
            nl++;
        }
    }
    // LASTNAME UPDATE
    private static void UpdateLastName(String lastName){
        String queString = "UPDATE students set LNAME = ? WHERE STD_ID ="+"'"+getID()+"'";
        if(checkSurname(getID(),getSurname())){
            System.out.println("["+getID()+"]"+" Cannot change lastname to "+getSurname());
            ll--;
        } else if(lastName.isBlank()||lastName.isEmpty()){
            System.out.println("----------------------------------------------------------------");
            System.out.println("|                    SURNAME CANNOT BE EMPTY                    |");
            System.out.println("----------------------------------------------------------------");
        } else {
            try {
                dB.DbConnect();
                PreparedStatement ps = DbConnection.con.prepareStatement(queString);
                ps.setString(1, lastName);
                int rawUp = ps.executeUpdate();
                if(rawUp>0){
                    System.out.println("********************************************************************************************************************************************");
                    System.out.println("|                                           ["+getID()+"],        SURNAME IS UPDATED SUCCESSFULLY                                               |");
                    System.out.println("********************************************************************************************************************************************");
                    SelectRecord.showData();
                    dB.DbCloseConnection();
                }
            } catch (SQLException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }          
            LastNamelist.add("["+ll+"] "+getID()+"     "+getSurname());
            ll++;
        }
    }

    private static boolean checkid(String id){
        String qString = "SELECT * FROM students WHERE STD_ID = ?";
        boolean ss = false;
        if(id.length()>6){
            ss = false;
        }
        try {
            dB.DbConnect();
            PreparedStatement ps = DbConnection.con.prepareStatement(qString);
            ps.setString(1, getID());
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                ss =true;
                dB.DbCloseConnection();
            }
        } catch (SQLException e) {
            System.err.println(e);
        }
        return ss;
    }

    private static boolean checkEmail(String id2, String email2) {
        String qString = "SELECT * FROM students WHERE STD_ID = ? AND EMAIL = ?";
        boolean ss = false;
        try {
            dB.DbConnect();
            PreparedStatement ps = DbConnection.con.prepareStatement(qString);
            ps.setString(1, id2);
            ps.setString(2, email2);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                ss =true;
                dB.DbCloseConnection();
            }
        } catch (SQLException e) {
            System.err.println(e);
        }
        return ss;
    }

    private static boolean checkAddress(String id2, String address2) {
        String qString = "SELECT * FROM students WHERE STD_ID = ? AND ADDRESS = ?";
        boolean ss = false;
        try {
            dB.DbConnect();
            PreparedStatement ps = DbConnection.con.prepareStatement(qString);
            ps.setString(1, id2);
            ps.setString(2, address2);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                ss =true;
                dB.DbCloseConnection();
            }
        } catch (SQLException e) {
            System.err.println(e);
        }
        return ss;
    }

    private static boolean checkCourse(String id2, String school2) {
        String qString = "SELECT * FROM students WHERE STD_ID = ? AND COURSE = ?";
        boolean ss = false;
        try {
            dB.DbConnect();
            PreparedStatement ps = DbConnection.con.prepareStatement(qString);
            ps.setString(1, id2);
            ps.setString(2, school2);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                ss =true;
                dB.DbCloseConnection();
            }
        } catch (SQLException e) {
            System.err.println(e);
        }
        return ss;
    }

    private static boolean checkSurname(String id,String surname){
        String qString = "SELECT * FROM students WHERE STD_ID = ? AND LNAME = ?";
        boolean ss = false;
        try {
            dB.DbConnect();
            PreparedStatement ps = DbConnection.con.prepareStatement(qString);
            ps.setString(1, getID());
            ps.setString(2, getSurname());
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                ss =true;
                dB.DbCloseConnection();
            }
        } catch (SQLException e) {
            System.err.println(e);
        }
        return ss;
    }
    
    private static boolean checkFirstName(String id,String name){
        String qString = "SELECT * FROM students WHERE STD_ID = ? AND FNAME = ?";
        boolean ss = false;
        try {
            dB.DbConnect();
            PreparedStatement ps = DbConnection.con.prepareStatement(qString);
            ps.setString(1, getID());
            ps.setString(2, getName());
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                ss =true;
                dB.DbCloseConnection();
            }
        } catch (SQLException e) {
            System.err.println(e);
        }
        return ss;
    }

    private static boolean checkSchool(String id,String school){
        String qString = "SELECT * FROM students WHERE STD_ID = ? AND SCHOOL = ?";
        boolean ss = false;
        try {
            dB.DbConnect();
            PreparedStatement ps = DbConnection.con.prepareStatement(qString);
            ps.setString(1, getID());
            ps.setString(2, getSchool());
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                ss =true;
                dB.DbCloseConnection();
            }
        } catch (SQLException e) {
            System.err.println(e);
        }
        return ss;
    }

    private static boolean formKey(char key){
        boolean ans = false;
        if(in =='y'){
            ans = true;
        }
        if(in =='Y'){
            ans = true;
        }
        if(in =='n'){
            ans = true;
        }
        if(in =='N'){
            ans = true;
        }
        return ans;
    }

    private static boolean formKeyOrg(char myAns){
        boolean myans = false;
        if(key =='1'){
            myans = true;
        }
        if(key =='2'){
            myans = true;
        }
        if(key =='3'){
            myans = true;
        }
        if(key =='4'){
            myans = true;
        }
        if(key =='5'){
            myans = true;
        }
        if(key =='6'){
            myans = true;
        }
        if(key =='7'){
            myans = true;
        }
        return myans;
    }
    
    // FORMS

    private static void emailForm() {
        System.out.println("=======================================");
        System.out.println("|         UPDATE EMAIL SECTION        |");
        System.out.println("=======================================");
        System.out.println("******************************");
        System.out.println("|  ENTER ID TO UPDATE EMAIL  |");
        System.out.println("******************************");
        System.out.print("ID: ");
        id = s.next();
        s.skip(System.lineSeparator());
        while(!checkid(id)){
            System.out.println("********************************************************************************************************************************************");
            System.out.println("|                                                            INVALID STUDENT ID                                                            |");
            System.out.println("|                                                    LOOK FOR ID AT THE DATABASE RECORDS                                                   |");
            System.out.println("********************************************************************************************************************************************");
            SelectRecord.showData();
            System.out.print("ID: ");
            id = s.next();
            s.skip(System.lineSeparator());
        }
        System.out.print("ENTER NEW EMAIL: ");
        email= s.nextLine();
        if(email.isEmpty()){
            System.out.println("Field cannot be blank");
        }
        UpdateEmail(email);
    }

    private static void addressForm() {
        System.out.println("=======================================");
        System.out.println("|        UPDATE ADDRESS SECTION       |");
        System.out.println("=======================================");
        System.out.println("********************************");
        System.out.println("|  ENTER ID TO UPDATE ADDRESS  |");
        System.out.println("********************************");
        System.out.print("ID: ");
        id = s.next();
        s.skip(System.lineSeparator());
        while(!checkid(id)){
            System.out.println("********************************************************************************************************************************************");
            System.out.println("|                                                            INVALID STUDENT ID                                                            |");
            System.out.println("|                                                    LOOK FOR ID AT THE DATABASE RECORDS                                                   |");
            System.out.println("********************************************************************************************************************************************");
            SelectRecord.showData();
            System.out.print("ID: ");
            id = s.next();
            s.skip(System.lineSeparator());
        }
        System.out.print("ENTER NEW ADDRESS: ");
        address= s.nextLine();
        if(address.isEmpty()){
            System.out.println("Field cannot be blank");
        }
        UpdateAddress(address);
    }

    private static void lastNameForm(){
        System.out.println("=======================================");
        System.out.println("|       UPDATE LASTNAME SECTION       |");
        System.out.println("=======================================");
        System.out.println("*********************************");
        System.out.println("|  ENTER ID TO UPDATE LASTNAME  |");
        System.out.println("*********************************");
        System.out.print("ID: ");
        id = s.next();
        s.skip(System.lineSeparator());
        while(!checkid(id)){
            System.out.println("********************************************************************************************************************************************");
            System.out.println("|                                                            INVALID STUDENT ID                                                            |");
            System.out.println("|                                                    LOOK FOR ID AT THE DATABASE RECORDS                                                   |");
            System.out.println("********************************************************************************************************************************************");
            SelectRecord.showData();
            System.out.print("ID: ");
            id = s.next();
            s.skip(System.lineSeparator());
        }
        System.out.print("ENTER NEW LASTNAME: ");
        surname= s.nextLine();
        if(surname.isEmpty()){
            System.out.println("Field cannot be blank");
        }
        UpdateLastName(surname);
    }

    private static void firstNameForm(){
        System.out.println("=======================================");
        System.out.println("|       UPDATE FIRSTNAME SECTION      |");
        System.out.println("=======================================");
        System.out.println("**********************************");
        System.out.println("|  ENTER ID TO UPDATE FIRSTNAME  |");
        System.out.println("**********************************");
        System.out.print("ID: ");
        id = s.next();
        s.skip(System.lineSeparator());
        while(!checkid(id)){
            System.out.println("********************************************************************************************************************************************");
            System.out.println("|                                                            INVALID STUDENT ID                                                            |");
            System.out.println("|                                                    LOOK FOR ID AT THE DATABASE RECORDS                                                   |");
            System.out.println("********************************************************************************************************************************************");
            SelectRecord.showData();
            System.out.print("ID: ");
            id = s.next();
            s.skip(System.lineSeparator());
        }
        System.out.print("ENTER NEW NAME: ");
        name = s.nextLine();
        UpdateFirstName(name);
    }

    private static void courseForm(){
        System.out.println("=======================================");
        System.out.println("|         UPDATE COURSE SECTION       |");
        System.out.println("=======================================");
        System.out.println("*******************************");
        System.out.println("|  ENTER ID TO UPDATE COURSE  |");
        System.out.println("*******************************");
        System.out.print("ID: ");
        id = s.next();
        s.skip(System.lineSeparator());
        while(!checkid(id)){
            System.out.println("********************************************************************************************************************************************");
            System.out.println("|                                                            INVALID STUDENT ID                                                            |");
            System.out.println("|                                                    LOOK FOR ID AT THE DATABASE RECORDS                                                   |");
            System.out.println("********************************************************************************************************************************************");
            SelectRecord.showData();
            System.out.print("ID: ");
            id = s.next();
            s.skip(System.lineSeparator());
        }
        System.out.print("ENTER NEW COURSE: ");
        course = s.nextLine();
        UpdateCourse(course);
    }

    private static void schoolForm(){
        System.out.println("=======================================");
        System.out.println("|        UPDATE SCHOOL SECTION        |");
        System.out.println("=======================================");
        System.out.println("*******************************");
        System.out.println("|  ENTER ID TO UPDATE SCHOOL  |");
        System.out.println("*******************************");
        System.out.print("ID: ");
        id = s.next();
        s.skip(System.lineSeparator());
        while(!checkid(id)){
            System.out.println("********************************************************************************************************************************************");
            System.out.println("|                                                            INVALID STUDENT ID                                                            |");
            System.out.println("|                                                    LOOK FOR ID AT THE DATABASE RECORDS                                                   |");
            System.out.println("********************************************************************************************************************************************");
            SelectRecord.showData();
            System.out.print("ID: ");
            id = s.next();
            s.skip(System.lineSeparator());
        }
        System.out.print("ENTER NEW SCHOOL : ");
        school = s.nextLine();
        if(school.isEmpty()){
            System.out.println("Field cannot be blank");
        }
        UpdateSchool(school);
    }

    // Getter
    private static String getID(){
        return id;
    }
    private static String getSurname(){
        return surname;
    }
    private static String getName(){
        return name;
    }
    private static String getSchool(){
        return school;
    }
    private static String getEmail(){
        return email;
    }
    private static String getCourse(){
        return course;
    }
    private static String getAddress(){
        return address;
    }

    private static char getKey(){
        return in;
    }

    private static char getKey2(){
        return key;
    }
}
