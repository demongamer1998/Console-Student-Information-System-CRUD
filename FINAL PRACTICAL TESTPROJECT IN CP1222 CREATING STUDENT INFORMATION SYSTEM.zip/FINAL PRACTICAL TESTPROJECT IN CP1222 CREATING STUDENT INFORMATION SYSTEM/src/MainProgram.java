/**
*PROGRAMMED BY: Denmark Warrene Alulod
*SECTION: G-12-IC2AD
*DATE SUBMITTED: May, 11, 2022
*SUBJECT: CP1222
ICT-INSTRUCTOR: SIR SETH
*FINAL PRACTICAL TEST/PROJECT IN CP1222 CREATING STUDENT INFORMATION SYSTEM
**/
import java.util.Scanner;
public class MainProgram {
    static Scanner s = new Scanner(System.in);
    static char key;
    public static void main(String[] args){
        Form();
    }

    public static void Form(){
        do {
                System.out.println("****************************************************************");
                System.out.println("|            STUDENT INFORMATION SYSTEM IN JAVA JDBC           |");
                System.out.println("|            SIMPLE STUDENT RECORDING SYSTEM IN JAVA           |");
                System.out.println("****************************************************************");
                System.out.println("|                   [CP1222 - JAVA ACTIVITY]                   |");
                System.out.println("|                                                              |");
                System.out.println("|               1. ADD RECORDS IN THE DATABASE                 |");
                System.out.println("|               2. VIEW RECORDS IN THE DATABASE                |");
                System.out.println("|               3. EDIT RECORDS IN THE DATABASE                |");
                System.out.println("|               4. DELETE RECORDS IN THE DATABASE              |");
                System.out.println("|               5. QUIT DATABASE APPLICATION                   |");
                System.out.println("|                                                              |");
                System.out.println("****************************************************************");
                newForm();
        } while (key != '5');
    }

    static void newForm(){
        System.out.print("SELECT ITEM :> ");
        key = s.next().charAt(0);
        if (key=='1'||key=='2'||key=='3'||key=='4'||key=='5'){
            switch (key) {
                case '1':
                    System.out.println("You selected option 1: ADD DATABASE RECORD");
                    InsertData.insertStudents();
                    break;
                case '2':
                    System.out.println("You selected option 2: VIEW DATABASE RECORD");
                    SelectRecord.recordForm();
                    break;
                case '3':
                    System.out.println("You selected option 3: UPDATE DATABASE RECORD");
                    UpdateRecord.UpdateStudentCredentials();
                    break;
                case '4':
                    System.out.println("You selected option 4: DELETE DATABASE RECORD");
                    DeleteRecord.DeleteStudentRecord();
                    break;
                case '5':
                    System.out.println("You selected option 5: DELETE DATABASE RECORD");
                    System.out.println("Program has been ended, Sayonara!");
                    break;
            } 
        } else {
            System.out.println("Invalid input.......");;
            newForm();
        }
    }

}
