/**
*PROGRAMMED BY: Denmark Warrene Alulod
*SECTION: G-12-IC2AD
*DATE SUBMITTED: May, 11, 2022
*SUBJECT: CP1222
ICT-INSTRUCTOR: SIR SETH
*FINAL PRACTICAL TEST/PROJECT IN CP1222 CREATING STUDENT INFORMATION SYSTEM
**/
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;
import java.util.ArrayList;
import java.util.Scanner;

import com.mysql.cj.jdbc.exceptions.MysqlDataTruncation;

public class InsertData {
    static Scanner s = new Scanner(System.in);
    static int i=0;
    static String num_id,fname,lname,address,course,school,email;
    static char in;
    static DbConnection dB = new DbConnection();

    static ArrayList<String> List = new ArrayList<String>();

        //Insert Method
        public static void insertStudents(){
            i=i+1;
            do {
                newForm();
                } while (in != 'n'||in != 'N');
        }

        static void newForm(){
            System.out.println("*************************************");
            System.out.println("| INSERT SINGLE RECORD IN THE TABLE |");
            System.out.println("*************************************");
            try {
                // ID
                System.out.print("ID Number: ");
                num_id = s.nextLine();
    
                // FIRSTNAME
                System.out.print("First Name: ");
                
                fname = s.nextLine();
    
                // LASTNAME
                System.out.print("Last Name: ");
                lname = s.nextLine();
    
                // COURSE
                System.out.print("Course: ");
                course = s.nextLine();

                // COURSE
                System.out.print("School: ");
                school = s.nextLine();
    
                // ADDRESS
                System.out.print("Address: ");
                address = s.nextLine();

                // EMAIL
                System.out.print("Email: ");
                email = s.nextLine();
                // insert DATA
                insertRec(num_id, fname, lname, course, school, address,email);
                } catch (Exception e) {
                    System.err.printf("WE ENCOUNTER SOME ERROR",e+"\n");
                }
                newCon();
        }

        static void newCon(){
            do {
                System.out.println("****************************************************************");
                System.out.println("|                     INSERT ANOTHER DATA                      |");
                System.out.println("|                      PRESS [N] FOR YES                       |");
                System.out.println("|                      PRESS [Y] FOR NO                        |");
                System.out.println("****************************************************************");
                System.out.print("ENTER YOUR CHOICE: ");
                in = s.next().charAt(0);
                s.skip(System.lineSeparator());
                if (in =='y'||in =='Y'){
                    newForm();
                } if (in =='n'||in =='N'){
                    System.out.println("****************************************************************");
                    System.out.println("|                       RECENT DATA ENTRY                      |");
                    String [] names = List.toArray(new String[0]);
                    System.out.println("|                           ENTRIES                            |");
                    System.out.println("****************************************************************\n");
                    for(String s: names){
                        System.out.printf("%-40s\n",s);
                    }
                    System.out.println("\n|                    END OF THE TRANSACTION                   |");
                    System.out.println("****************************************************************");
                    List.clear();
                    i=0;
                    System.out.println("INSERTING DATA ENDS HERE......\n");
                    MainProgram.Form();
                } else {
                    System.out.println("Invalid input.....");
                    newCon();
                }
            } while (in!='n'||in!='N');
        }

        // Constructor
        private static void insertRec(String id, String fname, String lname, String course, String school , String address, String email) throws SQLException{

            if(id.isEmpty()){
                System.out.println("****************************************************************");
                System.out.println("|                     ID CANNOT BE EMPTY                       |");
                System.out.println("****************************************************************");
            } else if(fname.isEmpty()||fname.isBlank()){
                System.out.println("****************************************************************");
                System.out.println("|                     FIRSTNAME CANNOT BE EMPTY                |");
                System.out.println("****************************************************************");
            } else if(lname.isEmpty()||lname.isBlank()){
                System.out.println("****************************************************************");
                System.out.println("|                     LASTNAME CANNOT BE EMPTY                 |");
                System.out.println("****************************************************************");
            } else if(course.isEmpty()||course.isBlank()){
                System.out.println("****************************************************************");
                System.out.println("|                     COURSE CANNOT BE EMPTY                   |");
                System.out.println("****************************************************************");
            } else if(school.isEmpty()||school.isBlank()){
                System.out.println("****************************************************************");
                System.out.println("|                     SCHOOL CANNOT BE EMPTY                   |");
                System.out.println("****************************************************************");
            } else if(address.isEmpty()||address.isBlank()){
                System.out.println("****************************************************************");
                System.out.println("|                     ADDRESS CANNOT BE EMPTY                  |");
                System.out.println("****************************************************************");
            } else if(email.isEmpty()||email.isBlank()){
                System.out.println("****************************************************************");
                System.out.println("|                     EMAIL CANNOT BE EMPTY                    |");
                System.out.println("****************************************************************");
            } else{
                String query ="INSERT INTO STUDENTS(STD_ID, FNAME, LNAME, COURSE, SCHOOL, ADDRESS, EMAIL) VALUES(?, ?, ?, ?, ?, ?, ?)";
                try {
                dB.DbConnect();
                PreparedStatement preparedStatement = DbConnection.con.prepareStatement(query);
                preparedStatement.setString(1, id);
                preparedStatement.setString(2, fname);
                preparedStatement.setString(3, lname);
                preparedStatement.setString(4, course);
                preparedStatement.setString(5, school);
                preparedStatement.setString(6, address);
                preparedStatement.setString(7, email);
        
                int rowInserted = preparedStatement.executeUpdate();
                if (rowInserted>0){
                    System.out.println("****************************************************************");
                    System.out.println("                NEW RECORD INSERTED SUCCESSFULLY                \n");
                    System.out.println("\tID NUMBER: "+getID());
                    System.out.println("\tNAME: "+getLastName()+", "+getName());
                    System.out.println("\tCOURSE: "+getCourse());
                    System.out.println("\tSCHOOL: "+getSchool());
                    System.out.println("\tADDRESS: "+getAdress());
                    System.out.println("\tEMAIL: "+getEmail());
                    System.out.println("");
                    // Add NAME TO ARRAYLIST
                    List.add("["+i+"] "+getID()+"     "+lname+",     "+fname);
                    dB.DbCloseConnection();
                    i++;
                } else {
                    i--;
                }
                } catch (SQLIntegrityConstraintViolationException e) {
                    System.out.println("\nStudent already exists...\n");
                } catch (MysqlDataTruncation e){
                    System.out.println("\nInvalid input!");
                    System.out.println("ID is too long...\n");
                }
            }
    }

    // Getter
    private static String getName() {
        return fname;
    }
    private static String getID() {
        return num_id;
    }
    private static String getLastName() {
        return lname;
    }
    private static String getCourse() {
        return course;
    }
    private static String getSchool() {
        return school;
    }
    private static String getAdress() {
        return address;
    }
    private static String getEmail() {
        return email;
    }
}
