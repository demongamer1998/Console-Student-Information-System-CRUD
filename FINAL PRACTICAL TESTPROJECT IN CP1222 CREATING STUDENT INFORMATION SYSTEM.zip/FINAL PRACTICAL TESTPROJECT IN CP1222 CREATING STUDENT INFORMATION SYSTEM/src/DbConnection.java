/**
*PROGRAMMED BY: Denmark Warrene Alulod
*SECTION: G-12-IC2AD
*DATE SUBMITTED: May, 11, 2022
*SUBJECT: CP1222
ICT-INSTRUCTOR: SIR SETH
*FINAL PRACTICAL TEST/PROJECT IN CP1222 CREATING STUDENT INFORMATION SYSTEM
**/
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DbConnection {
    private final static String className = "com.mysql.cj.jdbc.Driver";
    private final static String url = "jdbc:mysql://localhost:3306/aicsdb" ;
    private final static String user = "root";
    private final static String pass = "062198RCpo321";
    public static Connection con;

    void DbConnect(){
        try {
            Class.forName(className);
            con = DriverManager.getConnection(url, user, pass);
            
        } catch (SQLException | ClassNotFoundException e) {
            //TODO: handle exception
            System.err.println("*Connection could not establish*\n"+e);
        }
    }

    void DbCloseConnection(){
        try {
            con.close();
        } catch (SQLException e) {
            // TODO Auto-generated catch block
            System.err.println("Something went wrong!");
        }
    }
}
