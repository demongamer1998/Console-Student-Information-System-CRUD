/**
*PROGRAMMED BY: Denmark Warrene Alulod
*SECTION: G-12-IC2AD
*DATE SUBMITTED: May, 11, 2022
*SUBJECT: CP1222
ICT-INSTRUCTOR: SIR SETH
*FINAL PRACTICAL TEST/PROJECT IN CP1222 CREATING STUDENT INFORMATION SYSTEM
**/
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class SelectRecord {

    static Scanner s = new Scanner(System.in);
    static DbConnection Db = new DbConnection();
    static String std_id = "student_id";
    static String std_name = "student_name";
    static String std_lastname = "student_lastname";
    static String std_course = "course";
    static String std_school = "school";
    static String std_address = "address";
    static String std_email = "email";
    static String parameterID,parameterCourse,parameterSurname,parameterSchool;
    static char in;
    //

    private static boolean checkid(String id){
        DbConnection dB = new DbConnection();
        String qString = "SELECT * FROM students WHERE STD_ID = ?";
        boolean ss = false;
        if(id.length()>6){
            ss = false;
        }
        try {
            dB.DbConnect();
            PreparedStatement ps = DbConnection.con.prepareStatement(qString);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                ss =true;
                dB.DbCloseConnection();
            }
        } catch (SQLException e) {
            System.err.println(e);
        }
        return ss;
    }

    private static boolean checkCourse(String Cour){
        DbConnection dB = new DbConnection();
        String qString = "SELECT * FROM students WHERE COURSE = ?";
        boolean ss = false;
        if(Cour.length()>255){
            ss = false;
        }
        try {
            dB.DbConnect();
            PreparedStatement ps = DbConnection.con.prepareStatement(qString);
            ps.setString(1, Cour);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                ss =true;
                dB.DbCloseConnection();
            }
        } catch (SQLException e) {
            System.err.println(e);
        }
        return ss;
    }

    private static boolean checkSurname(String Surn){
        DbConnection dB = new DbConnection();
        String qString = "SELECT * FROM students WHERE LNAME = ?";
        boolean ss = false;
        if(Surn.length()>255){
            ss = false;
        }
        try {
            dB.DbConnect();
            PreparedStatement ps = DbConnection.con.prepareStatement(qString);
            ps.setString(1, Surn);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                ss =true;
                dB.DbCloseConnection();
            }
        } catch (SQLException e) {
            System.err.println(e);
        }
        return ss;
    }

    private static boolean checkSchool(String Schoo){
        DbConnection dB = new DbConnection();
        String qString = "SELECT * FROM students WHERE SCHOOL = ?";
        boolean ss = false;
        if(Schoo.length()>255){
            ss = false;
        }
        try {
            dB.DbConnect();
            PreparedStatement ps = DbConnection.con.prepareStatement(qString);
            ps.setString(1, Schoo);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                ss =true;
                dB.DbCloseConnection();
            }
        } catch (SQLException e) {
            System.err.println(e);
        }
        return ss;
    }


    static void showData(){
        String names,lastnames,addresses,courses,schools,emails,ids;
        try {
        System.out.println(" ");
        System.out.printf("%-20s%-20s%-20s%-10s%-15s%-25s%-30s\n", std_id,std_name,std_lastname,std_course,std_school,std_address,std_email);
        String query = "SELECT * FROM students";
        Db.DbConnect();
        Statement st = DbConnection.con.createStatement();
        ResultSet rs = st.executeQuery(query);
        while(rs.next()){
            ids = rs.getString("STD_ID");
            names  = rs.getString("FNAME");
            lastnames = rs.getString("LNAME");
            courses = rs.getString("COURSE");
            schools = rs.getString("SCHOOL");
            addresses = rs.getString("ADDRESS");
            emails = rs.getString("EMAIL");
            System.out.printf("%-20s%-20s%-20s%-10s%-15s%-25s%-30s\n", ids,names,lastnames,courses,schools,addresses,emails);
        }
        } catch (Exception e) {
            System.err.println(e);
        }
        System.out.println(" ");
        System.out.println("********************************************************************************************************************************************\n");
        Db.DbCloseConnection();
    }



    static void showSpecificDataByID(String id){
        String names,lastnames,addresses,courses,schools,emails,ids;
        String query = "SELECT * FROM students Where STD_ID = ?";
        try {
        System.out.println(" ");
        System.out.printf("%-20s%-20s%-20s%-10s%-15s%-25s%-30s\n", std_id,std_name,std_lastname,std_course,std_school,std_address,std_email);
        Db.DbConnect();
        PreparedStatement st = DbConnection.con.prepareStatement(query);
        st.setString(1, id);
        ResultSet rs = st.executeQuery();
        while(rs.next()){
            ids = rs.getString("STD_ID");
            names  = rs.getString("FNAME");
            lastnames = rs.getString("LNAME");
            courses = rs.getString("COURSE");
            schools = rs.getString("SCHOOL");
            addresses = rs.getString("ADDRESS");
            emails = rs.getString("EMAIL");
            System.out.printf("%-20s%-20s%-20s%-10s%-15s%-25s%-30s\n", ids,names,lastnames,courses,schools,addresses,emails);
        }
        } catch (Exception e) {
            System.err.println(e);
        }
        System.out.println(" ");
        System.out.println("********************************************************************************************************************************************\n");
        Db.DbCloseConnection();
    }

    static void showSpecificDataByCourse(String Course){
        String names,lastnames,addresses,courses,schools,emails,ids;
        String query = "SELECT * FROM students Where COURSE = ?";
        try {
        System.out.println(" ");
        System.out.printf("%-20s%-20s%-20s%-10s%-15s%-25s%-30s\n", std_id,std_name,std_lastname,std_course,std_school,std_address,std_email);
        Db.DbConnect();
        PreparedStatement st = DbConnection.con.prepareStatement(query);
        st.setString(1, Course);
        ResultSet rs = st.executeQuery();
        while(rs.next()){
            ids = rs.getString("STD_ID");
            names  = rs.getString("FNAME");
            lastnames = rs.getString("LNAME");
            courses = rs.getString("COURSE");
            schools = rs.getString("SCHOOL");
            addresses = rs.getString("ADDRESS");
            emails = rs.getString("EMAIL");
            System.out.printf("%-20s%-20s%-20s%-10s%-15s%-25s%-30s\n", ids,names,lastnames,courses,schools,addresses,emails);
        }
        } catch (Exception e) {
            System.err.println(e);
        }
        System.out.println(" ");
        System.out.println("********************************************************************************************************************************************\n");
        Db.DbCloseConnection();
    }

    static void showSpecificDataBySurname(String Surname){
        String names,lastnames,addresses,courses,schools,emails,ids;
        String query = "SELECT * FROM students Where LNAME = ?";
        try {
        System.out.println(" ");
        System.out.printf("%-20s%-20s%-20s%-10s%-15s%-25s%-30s\n", std_id,std_name,std_lastname,std_course,std_school,std_address,std_email);
        Db.DbConnect();
        PreparedStatement st = DbConnection.con.prepareStatement(query);
        st.setString(1,Surname);
        ResultSet rs = st.executeQuery();
        while(rs.next()){
            ids = rs.getString("STD_ID");
            names  = rs.getString("FNAME");
            lastnames = rs.getString("LNAME");
            courses = rs.getString("COURSE");
            schools = rs.getString("SCHOOL");
            addresses = rs.getString("ADDRESS");
            emails = rs.getString("EMAIL");
            System.out.printf("%-20s%-20s%-20s%-10s%-15s%-25s%-30s\n", ids,names,lastnames,courses,schools,addresses,emails);
        }
        } catch (Exception e) {
            System.err.println(e);
        }
        System.out.println(" ");
        System.out.println("********************************************************************************************************************************************\n");
        Db.DbCloseConnection();
    }

    static void showSpecificDataBySchool(String School){
        String names,lastnames,addresses,courses,schools,emails,ids;
        String query = "SELECT * FROM students Where SCHOOL = ?";
        try {
        System.out.println(" ");
        System.out.printf("%-20s%-20s%-20s%-10s%-15s%-25s%-30s\n", std_id,std_name,std_lastname,std_course,std_school,std_address,std_email);
        Db.DbConnect();
        PreparedStatement st = DbConnection.con.prepareStatement(query);
        st.setString(1,School);
        ResultSet rs = st.executeQuery();
        while(rs.next()){
            ids = rs.getString("STD_ID");
            names  = rs.getString("FNAME");
            lastnames = rs.getString("LNAME");
            courses = rs.getString("COURSE");
            schools = rs.getString("SCHOOL");
            addresses = rs.getString("ADDRESS");
            emails = rs.getString("EMAIL");
            System.out.printf("%-20s%-20s%-20s%-10s%-15s%-25s%-30s\n", ids,names,lastnames,courses,schools,addresses,emails);
        }
        } catch (Exception e) {
            System.err.println(e);
        }
        System.out.println(" ");
        System.out.println("********************************************************************************************************************************************\n");
        Db.DbCloseConnection();
    }

    static void newForm(){
        System.out.print("ENTER YOUR CHOICE: ");
        in = s.next().charAt(0);
            if(in=='1'||in=='2'||in=='3'||in=='4'||in=='5'||in=='6'){
                switch (in) {
                    case '1':
                    System.out.println("You selected option 1: SHOW ALL RECORDS");
                    System.out.println("********************************************************************************************************************************************");
                    System.out.println("                                                       SHOW ALL DATABASE RECORD LIST                                                        ");
                    System.out.println("********************************************************************************************************************************************");
                        showData();
                        break;
                    case '2':
                    System.out.println("You selected option 2: SHOW SINGLE RECORD THROUGH ID");
                    System.out.println("**********************");
                    System.out.println("| ENTER STUDENT'S ID |");
                    System.out.println("**********************");
                    System.out.print("ID : ");
                    parameterID = s.next();
                    if(!checkid(parameterID)){
                        System.out.println("\nThere is no such record......\n");
                    } else {
                        System.out.println("********************************************************************************************************************************************");
                        System.out.println("|                                                     SELECTED DATA INFORMATION BY ID                                                      |");
                        System.out.println("********************************************************************************************************************************************");
                            showSpecificDataByID(parameterID);
                    }
                        break;
                    case '3':
                    System.out.println("You selected option 3: SHOW RECORDS THROUGH COURSES");
                    System.out.println("**************************");
                    System.out.println("| ENTER STUDENT'S COURSE |");
                    System.out.println("**************************");
                    System.out.print("COURSE : ");
                    parameterCourse = s.next();
                        if(!checkCourse(parameterCourse)){
                            System.out.println("\nThere is no such record......\n");
                        } else {
                            System.out.println("********************************************************************************************************************************************");
                            System.out.println("|                                                   SELECTED DATA INFORMATION BY COURSE                                                    |");
                            System.out.println("********************************************************************************************************************************************");
                                showSpecificDataByCourse(parameterCourse);
                        }
                        break;
                    case '4':
                    System.out.println("You selected option 4: SHOW RECORDS THROUGH SURNAME");
                    System.out.println("**************************");
                    System.out.println("| ENTER STUDENT'S SURNAME |");
                    System.out.println("**************************");
                    System.out.print("SURNAME : ");
                    parameterSurname = s.next();
                        if(!checkSurname(parameterSurname)){
                            System.out.println("\nThere is no such record......\n");
                        } else {
                            System.out.println("********************************************************************************************************************************************");
                            System.out.println("|                                                   SELECTED DATA INFORMATION BY SURNAME                                                   |");
                            System.out.println("********************************************************************************************************************************************");
                                showSpecificDataBySurname(parameterSurname);
                        }
                        break;
                    case '5':
                    System.out.println("You selected option 5: SHOW RECORDS THROUGH SCHOOL");
                    System.out.println("**************************");
                    System.out.println("| ENTER STUDENT'S SCHOOL |");
                    System.out.println("**************************");
                    System.out.print("SCHOOL : ");
                    parameterSchool = s.next();
                        if (!checkSchool(parameterSchool)){
                            System.out.println("\nThere is no such record......\n");
                        } else {
                            System.out.println("********************************************************************************************************************************************");
                            System.out.println("|                                                   SELECTED DATA INFORMATION BY SCHOOL                                                    |");
                            System.out.println("********************************************************************************************************************************************");
                                showSpecificDataBySchool(parameterSchool);
                        }
                        break;
                    case '6':
                    System.out.println("You selected option 6: QUIT VIEW DATABASE RECORDS");
                        break;
                    default:
                        System.out.println("**************************");
                        System.out.println("| VIEW RECORD ENDS HERE |");
                        System.out.println("**************************");
                        break;
                }
            } else {
                System.out.println("Invalid Choice.........");
                newForm();
            }
    }

    static void recordForm(){
        do {
            System.out.println("******************************************************");
            System.out.println("|                SELECT RECORDS SECTION              |");
            System.out.println("******************************************************");
            System.out.println("|           1. SHOW ALL RECORDS                      |");
            System.out.println("|           2. SHOW SINGLE RECORD THROUGH ID         |");
            System.out.println("|           3. SHOW RECORDS THROUGH COURSES          |");
            System.out.println("|           4. SHOW RECORDS THROUGH SURNAME          |");
            System.out.println("|           5. SHOW RECORDS THROUGH SCHOOL           |");
            System.out.println("|           6. QUIT VIEW DATABASE RECORDS            |");
            System.out.println("******************************************************");
            newForm();
        } while (in != '6');
    }
}
