/**
*PROGRAMMED BY: Denmark Warrene Alulod
*SECTION: G-12-IC2AD
*DATE SUBMITTED: May, 11, 2022
*SUBJECT: CP1222
ICT-INSTRUCTOR: SIR SETH
*FINAL PRACTICAL TEST/PROJECT IN CP1222 CREATING STUDENT INFORMATION SYSTEM
**/
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;

public class DeleteRecord {
    static Scanner s = new Scanner(System.in);
    static String ID;
    static int i;
    static char in,on;
    static String names,lastnames,addresses,courses,schools,emails,ids;
    static String std_id = "student_id";
    static String std_name = "student_name";
    static String std_lastname = "student_lastname";
    static String std_course = "course";
    static String std_school = "school";
    static String std_address = "address";
    static String std_email = "email";
    static ArrayList<String> list = new ArrayList<>();
    static DbConnection dB = new DbConnection();

    static void DeleteStudentRecord(){
        i = i+1;
        do {
            System.out.println("=========================================");
            System.out.println("|          DELETE DATA SECTION          |");
            System.out.println("=========================================");
            System.out.print("ENTER ID NUMBER TO DELETE RECORD: ");
            ID = s.next();
            if(ID.isEmpty()){
                System.out.println("This field cannot be empty");
            }

            while (!checkID(ID)){
                System.out.println("********************************************************************************************************************************************");
                System.out.println("|                                                            INVALID STUDENT ID                                                            |");
                System.out.println("|                                                    LOOK FOR ID AT THE DATABASE RECORDS                                                   |");
                System.out.println("********************************************************************************************************************************************");
                SelectRecord.showData();
                System.out.print("ENTER ID NUMBER TO DELETE RECORD: ");
                ID = s.next();
            }
            System.out.println("********************************************************************************************************************************************");
            System.out.println("|                                                        SELECTED DATA INFORMATION                                                         |");
            System.out.println("********************************************************************************************************************************************\n");
            System.out.printf("%-20s%-20s%-20s%-10s%-15s%-25s%-30s\n", std_id,std_name,std_lastname,std_course,std_school,std_address,std_email);
            showSpecificDataByID2(ID);
            System.out.println(" ");
            System.out.println("********************************************************************************************************************************************\n");
            System.out.println("************************************");
            System.out.println("| ARE YOU SURE TO DELETE THIS DATA |");
            System.out.println("|        ENTER [N] FOR YES         |");
            System.out.println("|        ENTER [Y] FOR NO          |");
            System.out.println("************************************");
            System.out.print("ENTER YOUR CHOICE: ");
            on = s.next().charAt(0);
            while(!checkMe(on)){
                System.out.println("************************************");
                System.out.println("| ARE YOU SURE TO DELETE THIS DATA |");
                System.out.println("|        ENTER [N] FOR YES         |");
                System.out.println("|        ENTER [Y] FOR NO          |");
                System.out.println("************************************");
                System.out.print("ENTER YOUR CHOICE: ");
                on = s.next().charAt(0);
            }
            if (on=='Y'||on=='y'){
                deleteRecords(ID);
            } else if (on =='n'||on=='N') {
                System.out.println("********************************************************************************************************************************************");
                System.out.println("|                                                        NO DATA HAVE BEEN DELETED                                                         |");
                System.out.println("********************************************************************************************************************************************");
                SelectRecord.showData();
            } 
                System.out.println("***********************");
                System.out.println("| DELETE ANOTHER DATA |");
                System.out.println("|  PRESS [Y] FOR YES  |");
                System.out.println("|   PRESS [N] FOR NO  |");
                System.out.println("***********************");
                System.out.print("ENTER YOUR CHOICE: ");
                in = s.next().charAt(0);
                while(!checkMe2(in)){
                    System.out.println("***********************");
                    System.out.println("| DELETE ANOTHER DATA |");
                    System.out.println("|  PRESS [N] FOR YES  |");
                    System.out.println("|   PRESS [Y] FOR NO  |");
                    System.out.println("***********************");
                    System.out.print("ENTER YOUR CHOICE: ");
                    in = s.next().charAt(0);
                }
        } while (in =='Y'|| in == 'y');
            String [] names = list.toArray(new String [0]);
            System.out.println("********************************************************************************************************************************************");
            System.out.println("|                                                          RECENTLY DELETED DATA                                                           |");
            System.out.println("********************************************************************************************************************************************\n");
            for (String n : names) {
            System.out.printf("%20s\n",n);
            }
            System.out.println("\n********************************************************************************************************************************************");
            System.out.println("DELETING DATA ENDS HERE......\n");
            i=0;
            list.clear();
    }

    static void showSpecificDataByID2(String id){
        DbConnection Db = new DbConnection();
        String query = "SELECT * FROM students Where STD_ID = ?";
        try {
        Db.DbConnect();
        PreparedStatement st = DbConnection.con.prepareStatement(query);
        st.setString(1, id);
        ResultSet rs = st.executeQuery();
        while(rs.next()){
            ids = rs.getString("STD_ID");
            names  = rs.getString("FNAME");
            lastnames = rs.getString("LNAME");
            courses = rs.getString("COURSE");
            schools = rs.getString("SCHOOL");
            addresses = rs.getString("ADDRESS");
            emails = rs.getString("EMAIL");
            System.out.printf("%-20s%-20s%-20s%-10s%-15s%-25s%-30s\n", ids,names,lastnames,courses,schools,addresses,emails);     
        }
        } catch (Exception e) {
            System.err.println(e);
        }
        Db.DbCloseConnection();
    }

    static boolean checkMe(char on){
        boolean ans = false;
        if(on=='Y'){
            ans = true;
        }
        if(on=='y'){
            ans = true;
        }
        if(on=='N'){
            ans = true;
        }
        if(on=='n'){
            ans = true;
        }
        return ans;
    }

    static boolean checkMe2(char ans2){
        boolean Ans = false;
        if(in=='Y'){
            Ans = true;
        }
        if(in=='y'){
            Ans = true;
        }
        if(in=='N'){
            Ans = true;
        }
        if(in=='n'){
            Ans = true;
        }
        return Ans ;
    }

    private static boolean checkID(String id){
        String qString = "SELECT * FROM students WHERE STD_ID =?";
        boolean ss = false;
        try {
            dB.DbConnect();
            PreparedStatement ps = DbConnection.con.prepareStatement(qString);
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            if(rs.next()){
                ss =true;
            }
        } catch (SQLException e) {
            System.err.println(e);
        }
        return ss;
    }

    private static void deleteRecords(String idNum){
        String qString = "DELETE FROM students WHERE STD_ID =?";
            try {
                dB.DbConnect();
                PreparedStatement ps = DbConnection.con.prepareStatement(qString);
                ps.setString(1, idNum);
                int rs = ps.executeUpdate();
                if(rs>0){
                    System.out.println("********************************************************************************************************************************************");
                    System.out.println("|                                              [ "+getID()+" ]     RECORD DELETED SUCCESSFULLY                                                  |");
                    System.out.println("********************************************************************************************************************************************");
                    list.add("["+i+"]  "+ids+"     "+names+"     "+lastnames+"     "+courses+"     "+schools+"     "+addresses+"     "+emails);
                    i++;
                    SelectRecord.showData();
                    dB.DbCloseConnection();
                }
            } catch (Exception e) {
                System.err.println(e);
            }
    }

    static String getID(){
        return ID;
    }

    static Character getOn(){
        return on;
    }

    static Character getOn2(){
        return in;
    }
}
